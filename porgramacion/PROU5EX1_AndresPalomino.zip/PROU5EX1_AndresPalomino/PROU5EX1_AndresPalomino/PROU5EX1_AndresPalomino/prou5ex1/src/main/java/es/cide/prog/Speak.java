// Nombre: Andrés Palomino Cassain
// 45614964F
// Fecha: 9/12/25 --> 

package es.cide.prog;

public interface Speak {
    
    void sayHello();
    
    void sayGoodBye();
}
